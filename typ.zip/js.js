var typed = new Typed('.element', {
  strings: ["Oishi's Vatar", "i love acoda magi", "you love codacodi", "my voda gorom"],
  typeSpeed: 30,
  loop: true
});